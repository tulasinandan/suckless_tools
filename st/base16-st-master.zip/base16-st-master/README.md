base16 theme for st
===================

Base16 colors for the wonderful [st terminal][1] by suckless.

[Base16][2] provides carefully chosen syntax highlighting and a default set of
sixteen colors suitable for a wide range of applications. Base16 is not a
single theme but a set of guidelines with numerous implementations.

Installation
------------

Pick your favorite theme from the `build/` directory, and place its contents
into you `config.h` file.

License
-------

MIT

[1]: http://st.suckless.org/
[2]: https://github.com/chriskempson/base16
